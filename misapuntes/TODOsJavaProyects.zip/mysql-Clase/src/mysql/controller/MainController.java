package mysql.controller;

import mysql.model.sql.SqlManage;

public class MainController {
		SqlManage sql = new SqlManage();
		public boolean sqlUp() {
			return sql.comprobando();
		}
		public String select(String table) {
			return sql.select(table);
		}
		public String consultarEstado(int id) {
			return sql.comprobarEstado(id);
		}
		public void insertUser(String nombre) {
			sql.insertUser(nombre);
		}
		public void modificarUser(int id, String nombre) {
			sql.modificarUser(id, nombre);
		}
		public void modificarVehiculo(int id, String campo_n, String campo) {
			sql.modificarVehiculo(id, campo_n, campo);
		}
		public void insertVehicicle(int marca, String modelo, String matricula) {
			int t_matri = matricula.length();
			if (t_matri == 7) {
				sql.insertVehicle(marca, modelo, matricula);
			} else {
				System.out.print("No se pudo insertar: Matricula Invalida");
			}
		}
		
		// ALQUILERES
		public String  insertAlquiler(int id_user, int id_vehiculo, int duracion) {
			boolean user = sql.comprobarUser(id_user);
			boolean vehicle = sql.comprobarVehicle(id_vehiculo);
			String msg = "";
			if (user == true & vehicle == true) {
				sql.crearAlquiler(id_user, id_vehiculo, duracion); // añadir a SQL
				msg = "los datos existen";
			} else if (vehicle == false ) {
				msg = "No se pudo insertar ya que el vehiculo no esta disponible";
			} else if (user == false ) {
				msg =  "No se pudo insertar ya que el usuario no existe";
			}
			return msg;
			
			
		}
		
		
		public String salir() {
			return sql.close();
		}
}
