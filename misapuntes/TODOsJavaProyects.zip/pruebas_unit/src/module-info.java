/**
 * 
 */
/**
 * 
 */
module pruebas_unit {
	requires org.junit.jupiter.api;
}