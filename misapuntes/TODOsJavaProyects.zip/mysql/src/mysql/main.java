package mysql;

import mysql.view.MainView;
public class main {

	public static void main(String[] args) {
		MainView view = new MainView();
		view.run();
	}

}
