/**
 * 
 */
/**
 * 
 */
module mysql {
	requires java.sql;
	requires jdk.incubator.vector;
	requires org.junit.jupiter.api;
}