/**
 * 
 */
/**
 * 
 */
module examenEntornos {
	requires org.junit.jupiter.api;
}