/**
 * 
 */
/**
 * 
 */
module mysql {
	requires java.sql;
}