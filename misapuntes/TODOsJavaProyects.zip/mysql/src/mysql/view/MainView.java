package mysql.view;

import mysql.model.sql.SqlManage;

import java.io.ObjectInputFilter.Config;
import java.time.temporal.Temporal;

import mysql.controller.MainController;
import mysql.utils.TerminalUtils;

public class MainView {
	SqlManage sql = new SqlManage();
	MainController control = new MainController();
	public void run() {
		boolean connection = control.sqlUp();
		if (connection == true) {
			TerminalUtils.output("conectado");
				int i = 1;
				int option = 0;
				while (i != 0) {
					TerminalUtils.output("Menu de la apliacion \n 1. Consultar datos \n 2. Gestionar Usuarios \n 3. Gestionar Vehiculos \n 4. Alquilar Vehiculo \n 5. Gestion Facturas \n  0. salir ");
					option = TerminalUtils.inputInt();
					switch (option) {
						case 1 -> {
							TerminalUtils.output("Elige que deseas consultar \n 1. usuarios \n 2. vehiculos \n 3. Alquileres \n 4. Marcas \n 0. Atras");
							int tableint = TerminalUtils.inputInt();
							if (tableint > 0) {
								String table = "";
								switch (tableint) {
									case 1 ->table = "usuarios";
									case 2 ->table = "vehiculos";
									case 3 ->table = "alquiler";
									case 4 ->table = "marca";
									default -> throw new IllegalArgumentException("Unexpected value: " + tableint);
								}
								TerminalUtils.output(control.select(table));
							}
						}
						case 2 -> {
							TerminalUtils.output("Menu gestion usuarios: \n 1. Añadir usuario \n 2. Modificar perfil \n 0. Atras");
							int optiongu;
							optiongu = TerminalUtils.inputInt();
							switch (optiongu) {
								case 1 -> {
									TerminalUtils.output("introduce la el  nombre del usuario nuevo");
									String nombre = TerminalUtils.inputText();
									control.insertUser(nombre);
								}
								case 2 -> {
									TerminalUtils.output(control.select("usuarios")+"\n 0. Salir");
									TerminalUtils.output("Seleccione el id del usuario a modificar");
									int id = TerminalUtils.inputInt();
									if (id > 0) {
										TerminalUtils.output("introduce el nuveo nombre para el usuario con id "+id);
										String newName = TerminalUtils.inputText();
										control.modificarUser(id, newName);
									}
								}
							}
						}
						case 3 -> {
							TerminalUtils.output("Menu gestion Vehiculos: \n 1. Añadir vehiculo \n 2. Modificar vehiculo \n 3. Consultaar estado de un vehiculo  \n 0. Atras");
							int optiongv;
							optiongv = TerminalUtils.inputInt();
							switch (optiongv) {
								case 1 -> {
									TerminalUtils.output(control.select("marca")+"Introduce el ID de la marca del vehiculo nuevo");
									int marcaint = TerminalUtils.inputInt();
									TerminalUtils.output("introduce el modelo del vehiculo nuevo");
									String modelo = TerminalUtils.inputText();
									TerminalUtils.output("introduce la matricula del vehiculo nuevo");
									String matricula = TerminalUtils.inputText();
									control.insertVehicicle(marcaint, modelo, matricula);
								}
								case 2 -> {
									TerminalUtils.output(control.select("vehiculos")+"0. Salir");
									TerminalUtils.output("Seleccione el id del vehiculo a modificar");
									int id = TerminalUtils.inputInt();
									if (id > 0) {
										TerminalUtils.output("Selecciona el numero del campo a modificar: \n 1. Modelo \n 2. Marca");
										int n = TerminalUtils.inputInt();
										String campo_n = "";
										switch (n) {
											case 1 -> campo_n = "modelo";
											case 2 -> campo_n = "marca"; 
											default -> throw new IllegalArgumentException("Unexpected value: " + n);
										}
										TerminalUtils.output("introduce el nuveo "+campo_n+" para el usuario con id "+id);
										String campo = TerminalUtils.inputText();
										control.modificarVehiculo(id, campo_n, campo);
									}
								}
								case 3 -> {
									TerminalUtils.output(control.select("vehiculos")+" Selecciona el vehiculo para consultar su estado.");
									int id = TerminalUtils.inputInt();
									int option_cv = -1;
									while (option_cv != 0) {
										TerminalUtils.output(control.consultarEstado(id)+"\n 1. Desbloquear vehiculo \n 0. Volver");
										option_cv = TerminalUtils.inputInt();
										switch (option_cv) {
										case 1 -> {
											control.desbloquerVehiculo(id);
										}
										}
									}
								}
							}
						}
						case 4 -> {
							TerminalUtils.output("Menu gestion de Alquileres \n 1. Alquilar Vehiculo \n 2. Revisar Alquileres \n 0. Atras");
							int optiongv;
							optiongv = TerminalUtils.inputInt();
							switch (optiongv) {
								case 1 -> {
									TerminalUtils.output(control.select("usuarios")+"Introduce el ID del usuario que alquila el vehiculo");
									int id_user = TerminalUtils.inputInt();
									TerminalUtils.output(control.consultarEstado(0)+" Selecciona el vehiculo para consultar su estado actual");
									int id_vehiculo = TerminalUtils.inputInt();
									TerminalUtils.output("Duracion del alquiler");
									int duracion = TerminalUtils.inputInt();
									TerminalUtils.output(control.insertAlquiler(id_user, id_vehiculo, duracion));
								}
								case 2 ->  {
									TerminalUtils.output(control.select("alquiler"));
									int opt = -1;
									while (opt != 0) {
										TerminalUtils.output("Selecciona 1. para finalizar el alquiler \n 0. Salir");
										opt = TerminalUtils.inputInt();
										switch (opt) {
											case 1: {
												TerminalUtils.output("Selecciona el ID del alquiler a modificar");
												int id = TerminalUtils.inputInt();
												TerminalUtils.output("Esta pagado? 0(no)/1(si)");
												int pagado = TerminalUtils.inputInt();
												TerminalUtils.output("Se ha entredao el coche? 0(no)/1(si)")
												int entregado = TerminalUtils.inputInt();
												control.finalizarAlquier(id, pagado, entregado);
											}
										}
									}
								}
							}
						}
						case 5 -> {
							TerminalUtils.output("Menu gestion de Facturas \n 1. Ver Facturas \n 2. Crear Facturas \n 0. Atras");
							int optiongv;
							optiongv = TerminalUtils.inputInt();
							switch (optiongv) {
								case 1 ->  {
									TerminalUtils.output(control.select("facturas"));
								}
								case 2 -> {
									TerminalUtils.output(control.select("alquiler")+"Introduce el ID del alquiler al que se asocia la factura");
									int id_alquiler = TerminalUtils.inputInt();
									TerminalUtils.output("Concepto");
									String concepto = TerminalUtils.inputText();
									TerminalUtils.output(control.insertFactura(id_alquiler, concepto));
								}
							}
						}
						case 0  -> {
							TerminalUtils.output("Saliendo del programa \n"+control.salir());
							i = 0;
						}
						default -> {}
					}
				}
		} else {
			TerminalUtils.output("Hay un error en la conexion del a la base de datos");
		}
	}
}
