package ej2.view;

public class MainCliente {

	public int mostrar;

	public void mostrarMenu() {
		System.out.print("Menu de gestion de cliente \n 1. Cambiar Cliente \n 2. Añadir al carrito \n 3. Ver Carrito \n 4. Realizar pedido \n 0. Cancelar");
	}

	public void añadir() {
		// TODO Auto-generated method stub
		
	}

	public void cambiarCliente() {
		// TODO Auto-generated method stub
		
	}

	public void verCarrito() {
		// TODO Auto-generated method stub
		
	}

	public void realizarPedido() {
		// TODO Auto-generated method stub
		
	}

}
