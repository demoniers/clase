package ej2.view;

public class MainInventario {

	public void mostrarMenu() {
		System.out.print("Menu Inventario \n 1. Mostrar inventario \n 2. Añadir Stock \n 3. Editar Stock \n 4. Eliminar Producto \n 0. Atras");
	}

	public void eliminar() {
		// TODO Auto-generated method stub
		
	}

	public void editarProducto() {
		// TODO Auto-generated method stub
		
	}

	public void añadirProducto() {
		// TODO Auto-generated method stub
		
	}

	public void listarProductos() {
		// TODO Auto-generated method stub
		
	}

}
