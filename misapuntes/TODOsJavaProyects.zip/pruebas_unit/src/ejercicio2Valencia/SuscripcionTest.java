package ejercicio2Valencia;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ejercicio2Valencia.Suscripcion;

class SuscripcionTest {
	Suscripcion mySub;
	@BeforeEach 
	void iniciar() {
		 mySub =new Suscripcion(0, 0);
	}
	
	// PRECIO POR MES 
	@Test 
	public void precioPorMesTest() {
		mySub.setPeriodo(-1);
		double resultado = mySub.precioPorMes();
		assertEquals(0, resultado);
	}
	@Test 
	public void precioPorMesTest2() {
		mySub.setPrecio(-1);
		double resultado = mySub.precioPorMes();
		assertEquals(0, resultado);
	}
	@Test 
	public void precioPorMesTest3() {
		mySub.setPrecio(-1);
		mySub.setPeriodo(-1);
		double resultado = mySub.precioPorMes();
		assertEquals(0, resultado);
	}
	@Test 
	public void precioPorMesTest4() {
		mySub.setPrecio(5);
		mySub.setPeriodo(2);
		double resultado = mySub.precioPorMes();
		assertEquals(3.5, resultado);
	}
	@Test 
	public void precioPorMesTest5() {
		mySub.setPrecio(10);
		mySub.setPeriodo(2);
		double resultado = mySub.precioPorMes();
		assertEquals(5, resultado);
	}
	// CONSTRUCTOR
	@Test 
	public void constructor1() {
		mySub.setPeriodo(1);
		mySub.setPrecio(5);
		assertEquals(1, mySub.getPeriodo());
		assertEquals(5, mySub.getPrecio());
	}
}








