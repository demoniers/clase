package com.proyect.controller;

import java.util.List;

import com.proyect.model.ModelMemory;
import com.proyect.model.entities.*;

public class MainController {
	private ModelMemory model = new ModelMemory();

	public MainController() {
		// TODO Auto-generated constructor stub
	}

	public void nuevoComponente(String nombre) {
		model.addComponent(nombre);
	}
	public String listar() {
		return model.listar();
	}
	public void editar(int id, String nombre) {
		model.editarComponent(id, nombre);
	}
	public void eliminar(int id) {
		model.eliminarC(id);
	}
	public List<Componentes> list() {
		return model.listO();
	}

	public void nuevoComponenteExp(int idn, String nombreN) {
		model.addComponentExp(idn, nombre);		
	}

}
