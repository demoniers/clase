package ej1;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import com.project02.controller.MainController;
import com.project02.model.entities.Car;

public class Main {
	public static void main(String[] args) {
		System.out.print("Importando fichero");

		File importFile = new File("C:\\Users\\alumnofp\\Desktop\\examen2");
		try {
            Scanner reader = new Scanner(importFile);
            
            // Leer el archivo línea por línea
            while (reader.hasNextLine()) {
                String linea = reader.nextLine();
                String[] parte_ini = linea.split("@");
                double valorDouble = Double.parseDouble(parte_ini[4]);
                System.out.println("Para el día "+parte_ini[0]+" el consumo es de "+parte_ini[1]+" con un voltaje "+parte_ini[2]+" y una corriente de "+parte_ini[3]+" y una potencia de "+parte_ini[4]+". Lo que implica un costo de "+(valorDouble*0.2));
            }
            
            // Cerrar el Scanner
            reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

