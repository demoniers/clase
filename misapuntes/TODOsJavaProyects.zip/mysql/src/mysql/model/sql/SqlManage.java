package mysql.model.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import javax.xml.transform.Result;
import mysql.utils.TerminalUtils;

public class SqlManage {
    private static final String URL = "jdbc:mysql://localhost:3306/proyectjava?useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    private Connection connection;

    public Boolean comprobando() {
        return connecting(URL, USER, PASSWORD);
    }

    private Boolean connecting(String URL, String USER, String PASSWORD) {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            }
            return true;
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
            return false;
        }
    }
    
    
// SELECTS
    public String select(String table) {
    	String sql = "";
    	if (table == "vehiculos" ) {
    		sql = "SELECT vehiculos.*, marca.nombre FROM vehiculos INNER JOIN marca ON marca.id = vehiculos.marca";
    	} else if (table == "alquiler" ) {
    		sql = "SELECT alquiler.id_alquiler, alquiler.duracion, alquiler.inicio_alquiler, alquiler.entrega_fecha, alquiler.pagado, facturas.concepto, usuarios.nombre, vehiculos.modelo, vehiculos.matricula, marca.nombre AS nombre_marca FROM "+table+" INNER JOIN vehiculos ON alquiler.id_vehiculo = vehiculos.id INNER JOIN marca ON marca.id = vehiculos.marca INNER JOIN usuarios ON alquiler.id_usuario = usuarios.id LEFT JOIN facturas ON alquiler.id_factura = facturas.id";
    	} else {
    		sql = "SELECT * FROM " + table;
    	}
    	String lista = "";
        if (comprobando()) {
            try (
            		Statement statement = connection.createStatement();
            		ResultSet resultSet = statement.executeQuery(sql)) {
            		while (resultSet.next()) {
	                	switch (table) {
							case "usuarios" -> {
			                    int id = resultSet.getInt("id");
			                    String nombre = resultSet.getString("nombre");
			                   lista += "ID: " + id + ", Nombre: " + nombre+"\n";
							}
							case "vehiculos" -> {
			                    int id = resultSet.getInt("id");
			                    String modelo = resultSet.getString("modelo");
			                    String matricula = resultSet.getString("matricula");
			                    String marca = resultSet.getString("nombre");
			                   lista += "ID: " + id + ",  "+marca+" " + modelo+" Matricula: "+matricula+"\n";
							}
							case "alquiler" -> {
			                    // vehiculo
			                    String modelo = resultSet.getString("modelo");
			                    String matricula = resultSet.getString("matricula");
			                    String marca = resultSet.getString("nombre_marca");
			                    // usuarios
			                    String nombre = resultSet.getString("nombre");
			                    // factura
			                    String concepto = resultSet.getString("concepto");
			                    // alquiler
			                    int id_alquiler = resultSet.getInt("id_alquiler");
			                    int pagado = resultSet.getInt("pagado");
			                    String duracionStr = resultSet.getString("duracion");
			                    String fecha_inicioStr = resultSet.getString("inicio_alquiler"); // 2025-02-17 09:58:01
			                    String fecha_entregaStr = resultSet.getString("entrega_fecha"); // 2025-02-17
			                    
			                    int duracion = Integer.parseInt(duracionStr);
			                 // Use a formatter that matches the full timestamp
			                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			                    LocalDateTime fecha_inicioDateTime = LocalDateTime.parse(fecha_inicioStr, formatter);

			                    // Extract only the date part as LocalDate
			                    LocalDate fecha_inicio = fecha_inicioDateTime.toLocalDate();
			                    
			                    LocalDateTime fecha_hoy = null;
			                    if (fecha_entregaStr != null) {
				                    LocalDateTime fecha_entregaDate = LocalDateTime.parse(fecha_entregaStr, formatter);
				                    fecha_hoy = fecha_entregaDate;
			                    } else {
				                    fecha_hoy = LocalDateTime.now();			                    	
			                    }
			                    
			                    
			                    long diferencia = ChronoUnit.DAYS.between(fecha_inicio, fecha_hoy);

			                    String msg = "";
			                    if (diferencia > duracion) {
			                        msg = "Se ha pasado el plazo "+(diferencia-duracion)+" Dias";
			                    } else {
			                        msg = "En plazo";
			                    }
			                    if (concepto == null) {
			                    	concepto = "No hay concepto";
			                    }
			                    lista += id_alquiler + " alquilado por "+nombre+" Concepto: "+concepto+" | "+msg+"\n Inicio del alquiler: "+fecha_inicioStr+" Fecha Entrega: "+fecha_entregaStr+" Duracion:  " + duracion+" Pagado: "+pagado+"\n Datos del Vehiculo \n "+marca+"  "+modelo+":  Matricula: "+matricula+"\n";
							}
							default -> {
			                    int id = resultSet.getInt("id");
			                    String nombre = resultSet.getString("nombre");
			                   lista += "ID: " + id + ", Nombre: " + nombre+"\n";
							}
	                	}
                }
            } catch (SQLException e) {
                lista = "hubo un error";
            }
        }
        return lista;
    }
   
    public String comprobarEstado(int ids) {
    	String sql = "";
    	if (ids > 0) {
    		sql = "SELECT vehiculos.*, marca.nombre FROM vehiculos INNER JOIN marca ON marca.id = vehiculos.marca WHERE vehiculos.id = "+ids;
    	} else {
    		sql = "SELECT vehiculos.*, marca.nombre FROM vehiculos INNER JOIN marca ON marca.id = vehiculos.marca";
    	}
        if (comprobando()) {
        	String lista = "";
            try (
            		Statement statement = connection.createStatement();
            		ResultSet resultSet = statement.executeQuery(sql)) {
            		while (resultSet.next()) {
	                    int id = resultSet.getInt("id");
	                    String modelo = resultSet.getString("modelo");
	                    String matricula = resultSet.getString("matricula");
	                    String marca = resultSet.getString("nombre");
	                    String state = "";
	                    int estado = resultSet.getInt("estado");
	                    if (estado == 1) {
	                    	state = "Alquilado";
	                    } else {
	                    	state = "Libre";
	                    }
	                   lista += "ID: " + id + ",  "+marca+" " + modelo+" Matricula: "+matricula+" || Estado : "+state+"\n";
                	}
            } catch (SQLException e) {
                lista = "hubo un error";
            }
            return lista;
        } else {
        	return null;
        }
    }
    
    public Boolean comprobarUser(int id_user) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id_user);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("Hubo un error: " + e.getMessage());
        }
        return false;
    }

    public Boolean comprobarVehicle(int id_vehicle) {
        String sql = "SELECT COUNT(*) FROM vehiculos WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id_vehicle);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("Hubo un error: " + e.getMessage());
        }
        return false;
    }
    
    
// INSERTS
        public void insertUser(String nombre) {
            String sql = "INSERT INTO usuarios (nombre) VALUE (?)";
            if (comprobando()) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setString(1, nombre);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("¡Inserción exitosa!");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        public void insertVehicle(int marca, String modelo, String matricula) {
            String sql = "INSERT INTO vehiculos (marca, modelo, matricula) VALUE (?, ?, ?)";
            if (comprobando()) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, marca);
                    statement.setString(2, modelo);
                    statement.setString(3, matricula);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("¡Inserción exitosa!");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        public void crearAlquiler(int user, int vehicle, int duracion) {
            String sql = "INSERT INTO alquiler (id_usuario, id_vehiculo, duracion) VALUE (?, ?, ?)";
            modificarVehiculo(vehicle, "estado", "1");
            if (comprobando()) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, user);
                    statement.setInt(2, vehicle);
                    statement.setInt(3, duracion);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("¡Inserción exitosa!");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    	public void crearFactura(int id_alquiler, String concepto) {
            String sql = "INSERT INTO facturas (id_alquiler, concepto) VALUE (?, ?)";
            if (comprobando()) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, id_alquiler);
                    statement.setString(2, concepto);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("¡Inserción exitosa!");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
    	}
    
// UPDATES
        public void modificarUser(int id, String nombre) {
            String sql = "UPDATE usuarios SET nombre = ? WHERE id = ?";
            if (comprobando()) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                	statement.setInt(2, id);
                    statement.setString(1, nombre);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("¡Inserción exitosa!");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        public void modificarVehiculo(int id, String campo_n, String campo) {
            String sql = "UPDATE vehiculos SET "+campo_n+" = ? WHERE id = ?";
            if (comprobando()) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                	statement.setInt(2, id);
                    statement.setString(1, campo);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("¡Inserción exitosa!");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    	public void unlockVehicle(int id) {
    		 String sql = "UPDATE vehiculos SET estado= ? WHERE id = ?";
             if (comprobando()) {
                 try (PreparedStatement statement = connection.prepareStatement(sql)) {
                     statement.setInt(1, 0);
                 	statement.setInt(2, id);
                     int rowsInserted = statement.executeUpdate();
                     if (rowsInserted > 0) {
                         System.out.println("¡Inserción exitosa!");
                     }
                 } catch (SQLException e) {
                     e.printStackTrace();
                 }
             }
    	}

    
// EXIT
    public String close() {
        if (connection != null) {
            try {
                connection.close();
                String r = "Connection closed";
                return r;
            } catch (SQLException e) {
                String r = "Failed to close connection: " + e.getMessage();
                return r;
            }
        } else {
        	return null; 
        }
    }

	public void finalizarAlquiler(int id, int pagado2, int entregado) {
    String sql = "SELECT alquiler.id_alquiler, alquiler.duracion, alquiler.inicio_alquiler, alquiler.entrega_fecha, " +
                 "alquiler.pagado, alquiler.id_vehiculo, alquiler.id_factura, facturas.concepto, usuarios.nombre, " +
                 "vehiculos.modelo, vehiculos.matricula, marca.nombre AS nombre_marca " +
                 "FROM alquiler " +
                 "INNER JOIN vehiculos ON alquiler.id_vehiculo = vehiculos.id " +
                 "INNER JOIN marca ON marca.id = vehiculos.marca " +
                 "INNER JOIN usuarios ON alquiler.id_usuario = usuarios.id " +
                 "LEFT JOIN facturas ON alquiler.id_factura = facturas.id";

    String lista = "";
    int id_vehiculo = 0; // Variable para guardar el id_vehiculo
    int id_factura = 0;  // Variable para guardar el id_factura

    if (comprobando()) {
        try (
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql)
        ) {
            while (resultSet.next()) {
                // Recuperar id_vehiculo y id_factura
                id_vehiculo = resultSet.getInt("id_vehiculo");
                id_factura = resultSet.getInt("id_factura");

                // Otros datos relevantes de alquiler
                int id_alquiler = resultSet.getInt("id_alquiler");
                String nombre_usuario = resultSet.getString("nombre");
                String modelo = resultSet.getString("modelo");
                String matricula = resultSet.getString("matricula");
                String marca = resultSet.getString("nombre_marca");
                String concepto = resultSet.getString("concepto");
                int pagado = resultSet.getInt("pagado");
                String inicio_alquiler = resultSet.getString("inicio_alquiler");
                String entrega_fecha = resultSet.getString("entrega_fecha");
                int duracion = resultSet.getInt("duracion");

                // Calcular diferencia en días
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                LocalDate fecha_inicio = LocalDate.parse(inicio_alquiler, formatter);
                LocalDate fecha_hoy = (entrega_fecha != null) 
                    ? LocalDate.parse(entrega_fecha, formatter)
                    : LocalDate.now();

                long diferencia = ChronoUnit.DAYS.between(fecha_inicio, fecha_hoy);
                String msg = (diferencia > duracion) 
                    ? "Se ha pasado el plazo " + (diferencia - duracion) + " Días"
                    : "En plazo";

                if (concepto == null) {
                    concepto = "No hay concepto";
                }

                lista += id_alquiler + " alquilado por " + nombre_usuario + " Concepto: " + concepto + " | " + msg +
                        "\nInicio del alquiler: " + inicio_alquiler + " Fecha Entrega: " + entrega_fecha +
                        " Duración: " + duracion + " Pagado: " + pagado +
                        "\nDatos del Vehículo: " + marca + " " + modelo + " Matrícula: " + matricula + "\n";
            }
        } catch (SQLException e) {
            lista = "Hubo un error al procesar los datos.";
        }
    }
}
