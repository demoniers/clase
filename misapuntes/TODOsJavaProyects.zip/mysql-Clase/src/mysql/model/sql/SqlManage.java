package mysql.model.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.xml.transform.Result;

import mysql.utils.TerminalUtils;

public class SqlManage {
    private static final String URL = "jdbc:mysql://localhost:3306/proyectjava?useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    private Connection connection;

    public Boolean comprobando() {
        return connecting(URL, USER, PASSWORD);
    }

    private Boolean connecting(String URL, String USER, String PASSWORD) {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
            }
            return true;
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
            return false;
        }
    }
    
    
// SELECTS
    public String select(String table) {
    	String sql = "";
    	if (table == "vehiculos" ) {
    		sql = "SELECT vehiculos.*, marca.nombre FROM vehiculos INNER JOIN marca ON marca.id = vehiculos.marca";
    	} else {
    		sql = "SELECT * FROM " + table;
    	}
    	String lista = "";
        if (comprobando()) {
            try (
            		Statement statement = connection.createStatement();
            		ResultSet resultSet = statement.executeQuery(sql)) {
            		while (resultSet.next()) {
	                	switch (table) {
							case "usuarios" -> {
			                    int id = resultSet.getInt("id");
			                    String nombre = resultSet.getString("nombre");
			                   lista += "ID: " + id + ", Nombre: " + nombre+"\n";
							}
							case "vehiculos" -> {
			                    int id = resultSet.getInt("id");
			                    String modelo = resultSet.getString("modelo");
			                    String matricula = resultSet.getString("matricula");
			                    String marca = resultSet.getString("nombre");
			                   lista += "ID: " + id + ",  "+marca+" " + modelo+" Matricula: "+matricula+"\n";
							}
							default -> {
			                    int id = resultSet.getInt("id");
			                    String nombre = resultSet.getString("nombre");
			                   lista += "ID: " + id + ", Nombre: " + nombre+"\n";
							}
	                	}
                }
            } catch (SQLException e) {
                lista = "hubo un error";
            }
        }
        return lista;
    }
   
    public String comprobarEstado(int ids) {
    	String sql = "";
    	if (ids > 0) {
    		sql = "SELECT vehiculos.*, marca.nombre FROM vehiculos INNER JOIN marca ON marca.id = vehiculos.marca WHERE vehiculos.id = "+ids;
    	} else {
    		sql = "SELECT vehiculos.*, marca.nombre FROM vehiculos INNER JOIN marca ON marca.id = vehiculos.marca";
    	}
        if (comprobando()) {
        	String lista = "";
            try (
            		Statement statement = connection.createStatement();
            		ResultSet resultSet = statement.executeQuery(sql)) {
            		while (resultSet.next()) {
	                    int id = resultSet.getInt("id");
	                    String modelo = resultSet.getString("modelo");
	                    String matricula = resultSet.getString("matricula");
	                    String marca = resultSet.getString("nombre");
	                    String state = "";
	                    int estado = resultSet.getInt("estado");
	                    if (estado == 1) {
	                    	state = "Alquilado";
	                    } else {
	                    	state = "Libre";
	                    }
	                   lista += "ID: " + id + ",  "+marca+" " + modelo+" Matricula: "+matricula+" || Estado : "+state+"\n";
                	}
            } catch (SQLException e) {
                lista = "hubo un error";
            }
            return lista;
        } else {
        	return null;
        }
    }
    
    public Boolean comprobarUser(int id_user) {
        String sql = "SELECT COUNT(*) FROM usuarios WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id_user);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("Hubo un error: " + e.getMessage());
        }
        return false;
    }

    public Boolean comprobarVehicle(int id_vehicle) {
        String sql = "SELECT COUNT(*) FROM vehiculos WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id_vehicle);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.out.println("Hubo un error: " + e.getMessage());
        }
        return false;
    }
    
    

    public String comprobarAlquiler(int id_vehicle) {
        String sql = "SELECT * FROM alquiler INNER JOIN usuarios ON alquiler.id_usuario = usuarios.id INNER JOIN vehiculos ON alquiler.id_vehiculo = vehiculos.id INNER JOIN marca ON vehiculos.marca = marca.id LEFT JOIN facturas ON alquiler.id_factura = facturas.id  WHERE id = ?";

        if (comprobando()) {
        	String lista = "";
            try (
            		Statement statement = connection.createStatement();
            		ResultSet resultSet = statement.executeQuery(sql)) {
            		while (resultSet.next()) {
	                    int id = resultSet.getInt("id");
	                    int id_usuario = resultSet.getInt("id_usuario");
	                    String modelo = resultSet.getString("nombre");
	                    String matricula = resultSet.getString("matricula");
	                    String marca = resultSet.getString("nombre");
	                    String state = "";
	                    int estado = resultSet.getInt("estado");
	                    if (estado == 1) {
	                    	state = "Alquilado";
	                    } else {
	                    	state = "Libre";
	                    }
	                   lista += "ID: " + id + ",  "+marca+" " + modelo+" Matricula: "+matricula+" || Estado : "+state+"\n";
                	}
            } catch (SQLException e) {
                lista = "hubo un error";
            }
            return lista;
        } else {
        	return null;
        }
    }
    
    
// INSERTS
        public void insertUser(String nombre) {
            String sql = "INSERT INTO usuarios (nombre) VALUE (?)";
            if (comprobando()) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setString(1, nombre);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("¡Inserción exitosa!");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        public void insertVehicle(int marca, String modelo, String matricula) {
            String sql = "INSERT INTO vehiculos (marca, modelo, matricula) VALUE (?, ?, ?)";
            if (comprobando()) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, marca);
                    statement.setString(2, modelo);
                    statement.setString(3, matricula);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("¡Inserción exitosa!");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        public void crearAlquiler(int user, int vehicle, int duracion) {
            String sql = "INSERT INTO alquiler (id_usuario, id_vehiculo, duracion) VALUE (?, ?, ?)";
            modificarVehiculo(vehicle, "estado", "1");
            if (comprobando()) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, user);
                    statement.setInt(2, vehicle);
                    statement.setInt(3, duracion);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("¡Inserción exitosa!");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    
// UPDATES
        public void modificarUser(int id, String nombre) {
            String sql = "UPDATE usuarios SET nombre = ? WHERE id = ?";
            if (comprobando()) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                	statement.setInt(2, id);
                    statement.setString(1, nombre);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("¡Inserción exitosa!");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        public void modificarVehiculo(int id, String campo_n, String campo) {
            String sql = "UPDATE vehiculos SET "+campo_n+" = ? WHERE id = ?";
            if (comprobando()) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                	statement.setInt(2, id);
                    statement.setString(1, campo);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        System.out.println("¡Inserción exitosa!");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    
// EXIT
    public String close() {
        if (connection != null) {
            try {
                connection.close();
                String r = "Connection closed";
                return r;
            } catch (SQLException e) {
                String r = "Failed to close connection: " + e.getMessage();
                return r;
            }
        } else {
        	return null; 
        }
    }
}