package mysql;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class mainTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
