package examenEntornos.ej2;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import examenEntornos.ej1.FestivosException;

public class FestivosTest {
    
    private Festivos festivos;

    @BeforeEach
    public void setup() {
        festivos = new Festivos();
    }

    @Test
    public void testIncluirDiaFestivo() throws FestivosException {
        festivos.incluirDiaFestivo(100, "Holiday");
        assertTrue(festivos.consultarFestividad(100));
        String comp = festivos.consultarMotivoFestividad(100);
        assertEquals("Holiday", comp);
    }

    @Test
    public void testConsultarFestividad() throws FestivosException {
        festivos.incluirDiaFestivo(50, "Reason");
        assertTrue(festivos.consultarFestividad(50));
        boolean comp = festivos.consultarFestividad(60);
        assertFalse(comp);
    }

    @Test
    public void testConsultarMotivoFestividad() throws FestivosException {
        festivos.incluirDiaFestivo(20, "Festivo especial");
        assertEquals("Festivo especial", festivos.consultarMotivoFestividad(20));
        assertEquals("No es festivo", festivos.consultarMotivoFestividad(25));
    }

    @Test
    public void testContarDiasFestivos() throws FestivosException {
        festivos.incluirDiaFestivo(1, "Motivo 1");
        festivos.incluirDiaFestivo(2, "Motivo 2");
        assertEquals(2, festivos.contarDiasFestivos());
    }

    @Test
    public void testConsultarMesConMasFestivos() throws FestivosException {
        festivos.incluirDiaFestivo(0, "Enero");
        festivos.incluirDiaFestivo(1, "Enero");
        festivos.incluirDiaFestivo(31, "Febrero");
        assertEquals(1, festivos.consultarMesConMasFestivos()); // Enero tiene más festivos.
    }

    @Test
    public void testConsultarPrimerFestivo() throws FestivosException {
        festivos.incluirDiaFestivo(5, "Primer festivo");
        assertEquals(5, festivos.consultarPrimerFestivo());
    }

    @Test
    public void testDiasFestivosEnRango() throws FestivosException {
        festivos.incluirDiaFestivo(0, "Inicio");
        festivos.incluirDiaFestivo(5, "Medio");
        festivos.incluirDiaFestivo(10, "Fin");
        assertEquals(3, festivos.diasFestivos(0, 10));
    }

    @Test
    public void testComprobarDia() {
        FestivosException exception = assertThrows(FestivosException.class, () -> {
            festivos.comprobarDia(365);
        });
        assertEquals("El año no tiene tantos días", exception.getMessage());
    }
}
