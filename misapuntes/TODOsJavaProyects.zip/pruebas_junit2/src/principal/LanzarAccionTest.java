package principal;

import static org.junit.jupiter.api.Assertions.*;

import java.util.InputMismatchException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class LanzarAccionTest {
	LanzarAccion lanzador;
	@BeforeEach
	void Testing() {
		lanzador = new LanzarAccion();
	}
	
	public void TestInicializarAcciones() {
		int valor = null;
		assertThrows(InputMismatchException.class, () -> lanzador.recuperarValorEntrada());
	}

}




