package com.proyect.model;

import java.util.ArrayList;
import java.util.List;
import com.proyect.model.entities.Componentes;

public class ModelMemory {
	private List<Componentes> list;
	int id = 0;
	
	public ModelMemory() {
		list = new ArrayList<>();
	}
	public String listar() {
		String lista = "";
		for (Componentes myComp : list) {
			lista += myComp.getId()+": "+myComp.getNombre()+"\n"; 
		}
		return lista;
	}

	public void addComponent(String nombre) {
		Componentes myComp = new Componentes(id, nombre);
		list.add(myComp);
		id++;
	}
	public void addComponentExp(int idn, String nombre) {
		Componentes myComp = new Componentes(idn, nombre);
		list.add(myComp);
		id = idn;
	}
	
	public void editarComponent(int id, String newName) {
		for (Componentes myComp : list) {
			if (id == myComp.getId()) {
				myComp.setNombre(newName);
			}
		}
	}
	public void eliminarC(int id) {
		Componentes deleteC = null;
		for (Componentes myComp : list) {
			if (id == myComp.getId()) {
				deleteC = myComp;
				break;
			}
		}
		list.remove(deleteC);
	}
	public List<Componentes> listO() {
		return list;
	}

}
