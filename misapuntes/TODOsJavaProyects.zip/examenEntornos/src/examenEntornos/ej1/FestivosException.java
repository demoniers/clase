package examenEntornos.ej1;


public class FestivosException extends Exception {
	private static final long serialVersionUID = 1L;

	public FestivosException(String message) {
		super(message);
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}




