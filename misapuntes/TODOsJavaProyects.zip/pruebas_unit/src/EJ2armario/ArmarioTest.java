package EJ2armario;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Collection;
import java.util.HashSet;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class ArmarioTest {

	static Armario armario;
	
	@BeforeAll
	static void inicializar() {
		armario = new Armario();
		
		Collection<String> ropa = new HashSet<String>();
		ropa.add("camisa");
		ropa.add("pantalon");
		ropa.add("abrigo");
		
		armario.setRopa(ropa);
	}
	
	@Test
	void testPut() {		
		boolean resultado =armario.anadir("calcetin");
		assertTrue(armario.getRopa().contains("calcetin"));
		assertTrue(resultado);
	}
	
	@Test
	void testPutExist() {		
		boolean resultado =armario.anadir("camisa");
		assertFalse(resultado);
	}
	
	@Test
	void testContains() {
		assertTrue(armario.comprobar("pantalon"));
	}
	
	@Test
	void testNotContains() {
		assertFalse(armario.comprobar("chaqueta"));
	}
	
	@Test
	void testEliminar() throws NoSuchItemException {
		armario.eliminar("camisa");
		assertFalse(armario.getRopa().contains("camisa"));
	}
	
	@Test
	void testEliminarException() {
		
		NoSuchItemException exc = assertThrows(NoSuchItemException.class, 
				() -> armario.eliminar("zapatilla") );
		
		assertEquals("zapatilla no se encuentra en el armario", 
				exc.getMessage());
	}
	
}
