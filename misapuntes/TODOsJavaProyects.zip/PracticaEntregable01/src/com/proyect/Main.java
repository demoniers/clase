package com.proyect;

import com.proyect.view.MainView;

public class Main {
	public static void main(String[] args) {
		MainView mainView = new MainView();
		mainView.run();
	}
}
