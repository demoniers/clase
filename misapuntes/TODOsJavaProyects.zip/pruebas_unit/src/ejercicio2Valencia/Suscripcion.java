package ejercicio2Valencia;

public class Suscripcion {
	private int precio;
	private int periodo;

	public Suscripcion(int p, int n) {
		precio = p;
		periodo = n;
	}

	/**
	 * Calcular precio mensual de la suscripción.
	 */
	public double precioPorMes() {
		if (periodo <= 0 || precio <= 0) {
			return 0;
		}
		double r = (double) precio / (double) periodo;
		double resto = r % 1;
		if (resto > 0)
			return r + 1;
		else
			return r;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public int getPeriodo() {
		return periodo;
	}

	public void setPeriodo(int periodo) {
		this.periodo = periodo;
	}

	/**
	 * Cancelar la suscripción.
	 */
	public void cancel() {
		periodo = 0;
	}
}
