package com.proyect.view;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.List;
import java.util.ResourceBundle.Control;

import com.project02.model.entities.Car;
import com.proyect.controller.MainController;
import com.proyect.model.entities.Componentes;
import com.proyect.utils.TerminalUtils;

public class MainView {
	MainController control = new MainController();

	public mainView() {}
		
		public void run() {
			int option = -1;
			int option_in = -1;
			while (option != 0) {
				TerminalUtils.output("======================= \n Bienvenido PcStore menu de gestion \n 1. Gestionar Componentes \n 2. Gestionar Pedidos / Carritors \n 0. Salir ");
				option = TerminalUtils.inputInt();
				
				switch(option) {
					case 1 -> { // Gestion componentes
						TerminalUtils.output("Gestion Componentes \n 1. Crear un componente nuevo \n 2. listar todos los componentes \n 3. actualizar algún componente \n 4. eliminar alguno de los componentes \n 5. exportar datos a fichero");
						option_in = TerminalUtils.inputInt();
						switch(option_in) {
							case 1 -> {
								TerminalUtils.output("Introduzca el nombre del componente: ");
								String nombre = TerminalUtils.inputText();
								control.nuevoComponente(nombre);
							}
							case 2 ->{
								TerminalUtils.output(control.listar());
							}
							case 3 ->{
								TerminalUtils.output(control.listar());
								TerminalUtils.output("Seleccione el id del compoenete a modificar");
								int idm = TerminalUtils.inputInt();
								TerminalUtils.output("Introduce el nombe del componente con id "+idm);
								String nombreN = TerminalUtils.inputText();
								control.editar(idm, nombreN);
							}
							case 4 -> {
								TerminalUtils.output(control.listar());
								TerminalUtils.output("Seleccione el id del compoenete a eliminar");
								int idm = TerminalUtils.inputInt();
								control.eliminar(idm);
							}
							case 5 -> {
								List<Componentes> list = control.list();
								File myExportFile = new File("C:\\Users\\alumnofp\\Desktop\\exportFile");
								PrintWriter writer;
								try {
									writer = new PrintWriter(new FileWriter(myExportFile));
									
									for (Componentes myC : list) {
										writer.print(myC.toString());
									}
									writer.close();
								} catch (IOException e) {
									e.printStackTrace();
								}
							}
							case 6 -> {
								File importFile = new File("C:\\Users\\alumnofp\\Desktop\\exportFile");
								try {
						            Scanner reader = new Scanner(importFile);
						            
						            // Leer el archivo línea por línea
						            while (reader.hasNextLine()) {
						                String linea = reader.nextLine();
						                String[] parte = linea.split(" ");
	//					                int idn = parseInt(parte[0]);
						                String nombreN = parte[1];
						                control.nuevoComponenteExp(idn, nombreN);
						                System.out.println(linea);
						            }
						            
						            // Cerrar el Scanner
						            reader.close();
								} catch (IOException e) {
									e.printStackTrace();
								}		            
							}
						}
					}
					case 2 ->{ // gestion carrito
						TerminalUtils.output("Gestion Carritos \n ");
						option_in = TerminalUtils.inputInt();
						switch(option_in) {/*
							case 1 ->
							case 2 ->
							case 3 ->
							case 4 ->
							case 5 ->*/
						}
					}
					case 0 -> {// salir
						TerminalUtils.output("Sliendo del programa");
						break;
					}
				}
			}
		}


}
