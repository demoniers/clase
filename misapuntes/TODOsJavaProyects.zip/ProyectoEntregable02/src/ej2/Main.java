package ej2;

import ej2.controller.MainControl;

public class Main {
	
	public static void main(String[] args) {
		MainControl control = new MainControl();
		control.run();

	}

}
