package examenEntornos.ej1;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class FestivosExceptionTest {

    @Test
    public void testCrearExceptionConMensaje() {
        FestivosException exception = new FestivosException("Este es un mensaje de prueba");
        assertEquals("Este es un mensaje de prueba", exception.getMessage());
    }

    @Test
    public void testSerialVersionUID() {
        assertEquals(1L, FestivosException.getSerialversionuid());
    }
}
