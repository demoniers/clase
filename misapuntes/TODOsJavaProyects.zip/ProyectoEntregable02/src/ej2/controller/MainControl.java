package ej2.controller;

import java.util.Scanner;

import ej2.view.MainCliente;
import ej2.view.MainInventario;

public class MainControl {

	public void run() {
		MainCliente cliente = new MainCliente();
		MainInventario inventario = new MainInventario();
		
		Scanner sc = new Scanner(System.in);
		int option_ini = -1;
		while (option_ini != 0) {
			System.out.print("Introduce \n 1. Opciones Cliente \n 2. Opciones Inventario \n 0. Salir");
			option_ini = sc.nextInt();
			switch (option_ini) {
				case 1: {
					int option =-1;
					while (option != 0) {
						cliente.mostrarMenu();
						option = sc.nextInt();
						switch (option) {
							case 1: {
								cliente.cambiarCliente();
							}
							case 2: {
								cliente.añadir();
							}
							case 3: {
								cliente.verCarrito();
							}
							case 4: {
								cliente.realizarPedido();
							}
							case 0: {
								System.out.print("Volviendo al menu");
								break;
							}
						}
					}
					break;
				}
				case 2: {
					int option_inv = -1;
					while (option_inv != 0) {
						inventario.mostrarMenu();;
						option_inv = sc.nextInt();
						switch (option_inv) {
							case 1: {
								inventario.listarProductos();
							}
							case 2: {
								inventario.añadirProducto();
							}
							case 3: {
								inventario.editarProducto();
							}
							case 4: {
								inventario.eliminar();
							}
							case 0: {
								System.out.print("Volviendo al menu");
								break;
							}
						}
					}
				}
					case 0: {
						System.out.print("Saliendo");
					}
			}
		}
	}

}
