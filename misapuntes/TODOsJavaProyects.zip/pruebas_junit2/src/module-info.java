/**
 * 
 */
/**
 * 
 */
module pruebas_junit2 {
	requires org.junit.jupiter.api;
}