package mysql.view;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import mysql.controller.MainController;

public class MainViewTest {

    @Test
    public void testInsertUser() {
        MainController controller = new MainController();
        String resultado = controller.insertAlquiler(1, 1, 1);
        assertEquals("Usuario Juan añadido correctamente.", resultado);
    }
}