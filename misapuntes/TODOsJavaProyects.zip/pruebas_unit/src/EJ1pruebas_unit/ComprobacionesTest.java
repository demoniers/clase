package EJ1pruebas_unit;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*; // Para las anotaciones
import java.util.NoSuchElementException;

public class ComprobacionesTest {

    @Test
    public void testConstructorValido() {
        Integer[] enteros = {1, 2, 3};
        assertDoesNotThrow(() -> new Comprobaciones(enteros));
    }

    @Test
    @DisplayName("Test Constructor: Excepción por array nulo")
    public void testConstructorArrayNulo() {
        assertThrows(IllegalArgumentException.class, () -> new Comprobaciones(null),
                     "Se esperaba una IllegalArgumentException por array nulo");
    }

    @Test
    @DisplayName("Test Constructor: Excepción por array vacío")
    public void testConstructorArrayVacio() {
        assertThrows(IllegalArgumentException.class, () -> new Comprobaciones(new Integer[0]),
                     "Se esperaba una IllegalArgumentException por array vacío");
    }

    @Test
    @DisplayName("Test sumaEnteros: Suma correcta de los valores")
    public void testSumaEnteros() {
        Integer[] enteros = {1, 2, 3};
        Comprobaciones comprobaciones = new Comprobaciones(enteros);
        assertEquals(6, comprobaciones.sumaEnteros(), "La suma debe ser 6");
    }

    @Test
    @DisplayName("Test mayorValor: Devuelve el mayor valor correctamente")
    public void testMayorValor() {
        Integer[] enteros = {1, 3, 2};
        Comprobaciones comprobaciones = new Comprobaciones(enteros);
        assertEquals(3, comprobaciones.mayorValor(), "El mayor valor debe ser 3");
    }

    @Test
    @DisplayName("Test posicionValor: Devuelve la posición correcta")
    public void testPosicionValor() {
        Integer[] enteros = {10, 20, 30};
        Comprobaciones comprobaciones = new Comprobaciones(enteros);
        assertEquals(2, comprobaciones.posicionValor(20), "La posición de 20 debe ser 2");
    }

    @Test
    @DisplayName("Test posicionValor: Excepción por valor no encontrado")
    public void testPosicionValorNoEncontrado() {
        Integer[] enteros = {10, 20, 30};
        Comprobaciones comprobaciones = new Comprobaciones(enteros);
        assertThrows(NoSuchElementException.class, () -> comprobaciones.posicionValor(40),
                     "Se esperaba una NoSuchElementException para el valor 40");
    }

    @BeforeEach
    public void setUp() {
        System.out.println("Iniciando una prueba...");
    }

    @AfterEach
    public void tearDown() {
        System.out.println("Finalizando la prueba.");
    }

    @BeforeAll
    public static void setUpBeforeClass() {
        System.out.println("Preparando pruebas...");
    }

    @AfterAll
    public static void tearDownAfterClass() {
        System.out.println("Pruebas finalizadas.");
    }
}
